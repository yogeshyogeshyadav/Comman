<?php
/*==============================*/
// @package noisequarrel
// @author Himanshu
/*==============================*/
get_header(); 
?>
<!--============================== Content Start ==============================-->
<div class="content-container">
    <div class="container">
        <div class="row">
            <div class="col-md-12 os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.3s">
                <div class="heading"><h1><?php the_title(); ?></h1></div>
                <?php while(have_posts()): the_post(); the_content(); endwhile; ?>
            </div>
        </div>
    </div>
</div>
<!--============================== Content End ==============================-->  
<?php 
get_footer(); 
?>