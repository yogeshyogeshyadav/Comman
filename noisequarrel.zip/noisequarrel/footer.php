<?php 
$copyrights = get_field('copyrights','option');
?>

<!--============================== Modal register Start ==============================-->
<div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                ...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
<!--============================== Modal register End ==============================-->
<!--============================== Modal register Start ==============================-->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                ...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
<!--============================== Modal register End ==============================-->
<!--============================== Footer Start ==============================-->
<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1 text-center">
                <h3>Disclaimer</h3>
                <p>
                    his is a free social games website. All players must be over 18 years old. We remind players that practice and success on our site does not mean future success in playing for real money. The games offered are free and no
                    real money or prize money can be claimed.
                </p>
                <?php
                    wp_nav_menu( array(
                        'theme_location'    => 'footer_menu',
                        'depth'             => 1,
                        'container'         => false,
                        'menu_class'        => 'footer-nav',
                        'menu_id'           => 'footer-nav',
                        'items_wrap'        => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                    ));
                ?>
                <?php if(!empty($copyrights)): echo '<p class="copyright">'.do_shortcode($copyrights).'</p>'; endif; ?>
            </div>
        </div>
    </div>
</footer>
<!--============================== Footer End ==============================-->

<?php
wp_footer();
//edit_post_link('<i class="fas fa-pencil-alt"></i><b class="sr-only">Edit Page</b>','','',null,'edit-post-link');
?>
</body>
</html>