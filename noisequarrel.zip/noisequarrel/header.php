<?php
/*==============================*/
// @package noisequarrel
// @author Himanshu
/*==============================*/
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
wp_body_open();
?>
<!--============================== Header Start ==============================-->
<header id="header">
    <nav class="navbar navbar-expand-xl">
        <div class="container">
            <div class="nav-inside d-flex align-items-center justify-content-between">
                <a class="navbar-brand" href="#"><img src="include/images/logo.png" alt="" /></a>
                <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="navbar-collapse collapse" id="mainNav">
                  <div class="navbar-inside ml-auto">
                    <ul class="navbar-nav">
                        <li class="nav-item active"><a class="nav-link" href="#!">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!" data-toggle="modal" data-target="#registerModal">Register</a></li>    
                        <li class="nav-item"><a class="nav-link" href="#!" data-toggle="modal" data-target="#loginModal">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">Conatct Us</a></li>
                    </ul>

              </div>
                </div>
            </div>
        </div>
    </nav>
</header>
<!--============================== Header End ==============================--> 