<?php
/*==============================*/
// @package noisequarrel
// @author Himanshu
/*==============================*/
if(!defined('ABSPATH')){
    exit; // Exit if accessed directly
} 
get_header(); 
?>


<?php 
get_footer();
?>