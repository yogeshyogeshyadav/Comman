<?php
/*==============================*/
// @package noisequarrel
// @author Himanshu
/*==============================*/
/* Template Name: Contact */
get_header(); 
?>
<!--============================== Content Start ==============================-->
<div class="content-container">
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1">
            	<div class="form-heading">
					<h5>Contact Us</h5>
				</div>
            	<div class="form-wrapper">
            		<form method="post" action="#" id="messageForm">
				        <div class="col-md-4">
				            <div class="form-group">
				                <label>Your name</label>
				                <input type="text" value="" name="name" class="form-control" required />
				            </div>
				        </div>
				        <div class="col-md-4">
				            <div class="form-group">
				                <label>Your email</label>
				                <input type="email" value="" name="email" class="form-control" required />
				            </div>
				        </div>
				        <div class="col-md-4">
				            <div class="form-group">
				                <label>Subject</label>
				                <input type="text" value="" name="subject" class="form-control" required />
				            </div>
				        </div>
				        <div class="col-md-4">
				            <div class="form-group">
				                <label>Your message (optional)</label>
				                <textarea class="form-control" name="message" required></textarea>
				            </div>
				        </div>
				        <div class="col-md-4">
				            <div class="form-group">
				                <input type="submit" value="Send Message" class="btn btn-default btn-block" />
				            </div>
				        </div>
					</form>
            	</div>
            </div>
        </div>
    </div>
</div>
<!--============================== Footer Start ==============================-->

<?php get_footer(); ?>