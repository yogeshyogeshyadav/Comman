<?php
/*==============================*/
// @package noisequarrel
// @author Himanshu
/*==============================*/
/* Template Name: Homepage */
get_header(); 
?>
<!--============================== Content Start ==============================-->
<div class="content-container promotion-container">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ul class="promotion-list">
                    <li class="promotion-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.3s">
                        <div class="promotion-box d-lg-flex flex-lg-wrap">
                            <div class="promo-left">
                                <a href="#!" class="promo-log">
                                    <img src="include/images/casino-logo.png" alt="" />
                                </a>
                                <ul class="rating-list">
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                </ul>
                            </div>
                            <div class="promo-middle">
                                <ul class="bonus-list">
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <h4>₹20,000 <span>BONUS</span></h4>
                                        </div>
                                    </li>
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <h4>3000+ <span>GAMES</span></h4>
                                        </div>
                                    </li>
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <p>DEPOSIT <span> ₹5,000</span>, PLAY WITH <span>₹10,000</span></p>
                                            <ul>
                                                <li>New Indian casino 2021</li>
                                                <li>₹20,000 welcome package</li>
                                                <li>3000+ games</li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="promo-right">
                                <a href="#!" class="play-btn">Play now!</a>
                                <ul class="payment-mode-list">
                                    <li><img src="include/images/bank-transfer.svg" alt="" /></li>
                                    <li><img src="include/images/bitcoin.svg" alt="" /></li>
                                    <li><img src="include/images/mastercard.svg" alt="" /></li>
                                    <li><img src="include/images/skrill.svg" alt="" /></li>
                                    <li><img src="include/images/visa.svg" alt="" /></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="promotion-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.32s">
                        <div class="promotion-box d-lg-flex flex-lg-wrap">
                            <div class="promo-left">
                                <a href="#!" class="promo-log">
                                    <img src="include/images/megarush-logo.png" alt="" />
                                </a>
                                <ul class="rating-list">
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                </ul>
                            </div>
                            <div class="promo-middle">
                                <ul class="bonus-list">
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <h4>₹30,000 <span>BONUS</span></h4>
                                        </div>
                                    </li>
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <h4>₹100 <span>CASH FOR GOOD LUCK</span></h4>
                                        </div>
                                    </li>
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <p>DEPOSIT <span> ₹5,000</span>, PLAY WITH <span>₹10,000</span></p>
                                            <ul>
                                                <li>New Indian casino 2021</li>
                                                <li>₹20,000 welcome package</li>
                                                <li>3000+ games</li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="promo-right">
                                <a href="#!" class="play-btn">Play now!</a>
                                <ul class="payment-mode-list">
                                    <li><img src="include/images/bank-transfer.svg" alt="" /></li>
                                    <li><img src="include/images/bitcoin.svg" alt="" /></li>
                                    <li><img src="include/images/mastercard.svg" alt="" /></li>
                                    <li><img src="include/images/skrill.svg" alt="" /></li>
                                    <li><img src="include/images/visa.svg" alt="" /></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="promotion-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.34s">
                        <div class="promotion-box d-lg-flex flex-lg-wrap">
                            <div class="promo-left">
                                <a href="#!" class="promo-log">
                                    <img src="include/images/luckydays-logo.png" alt="" />
                                </a>
                                <ul class="rating-list">
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                </ul>
                            </div>
                            <div class="promo-middle">
                                <ul class="bonus-list">
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <h4>₹100,000 <span>BONUS</span></h4>
                                        </div>
                                    </li>
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <h4>4 <span>BONUSES</span></h4>
                                        </div>
                                    </li>
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <p>DEPOSIT <span> ₹5,000</span>, PLAY WITH <span>₹10,000</span></p>
                                            <ul>
                                                <li>New Indian casino 2021</li>
                                                <li>₹20,000 welcome package</li>
                                                <li>3000+ games</li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="promo-right">
                                <a href="#!" class="play-btn">Play now!</a>
                                <ul class="payment-mode-list">
                                    <li><img src="include/images/bank-transfer.svg" alt="" /></li>
                                    <li><img src="include/images/bitcoin.svg" alt="" /></li>
                                    <li><img src="include/images/mastercard.svg" alt="" /></li>
                                    <li><img src="include/images/skrill.svg" alt="" /></li>
                                    <li><img src="include/images/visa.svg" alt="" /></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="promotion-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.36s">
                        <div class="promotion-box d-lg-flex flex-lg-wrap">
                            <div class="promo-left">
                                <a href="#!" class="promo-log">
                                    <img src="include/images/purewin-logo.png" alt="" />
                                </a>
                                <ul class="rating-list">
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fas fa-star" aria-hidden="true"></i></li>
                                </ul>
                            </div>
                            <div class="promo-middle">
                                <ul class="bonus-list">
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <h4>₹90,000 <span>BONUS</span></h4>
                                        </div>
                                    </li>
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <h4>₹1,500 <span>LIVE CASINO BET</span></h4>
                                        </div>
                                    </li>
                                    <li class="bonus-item">
                                        <div class="bonus-box">
                                            <p>DEPOSIT <span> ₹5,000</span>, PLAY WITH <span>₹10,000</span></p>
                                            <ul>
                                                <li>New Indian casino 2021</li>
                                                <li>₹20,000 welcome package</li>
                                                <li>3000+ games</li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="promo-right">
                                <a href="#!" class="play-btn">Play now!</a>
                                <ul class="payment-mode-list">
                                    <li><img src="include/images/bank-transfer.svg" alt="" /></li>
                                    <li><img src="include/images/bitcoin.svg" alt="" /></li>
                                    <li><img src="include/images/mastercard.svg" alt="" /></li>
                                    <li><img src="include/images/skrill.svg" alt="" /></li>
                                    <li><img src="include/images/visa.svg" alt="" /></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!--============================== Content End ==============================-->
<!--============================== Content Start ==============================-->
<div class="content-container pt-0">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading text-center os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.3s">
                    <h3>WANNA PLAY?</h3>
                    <div class="add-heading-shadow">
                        <span class="ads-span left">
                            <span class="vc-sep-line"></span>
                        </span>
                        <span class="ads-span right">
                            <span class="vc-sep-line"></span>
                        </span>
                    </div>
                </div>

                <ul class="game-list d-flex flex-wrap">
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.3s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-twinspin.jpeg" alt="" />
                            </div>
                            <h4>Twin Spin</h4>

                            <div class="game-hover-content">
                                <h5>Twin Spin</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.31s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-turnyourfortune.jpeg" alt="" />
                            </div>
                            <h4>Turn Your Fortune</h4>
                            <div class="game-hover-content">
                                <h5>Turn Your Fortune</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.32s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-rome.jpeg" alt="" />
                            </div>
                            <h4>Rome</h4>
                            <div class="game-hover-content">
                                <h5>Rome</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.33s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-koiprincess.jpeg" alt="" />
                            </div>
                            <h4>Koi Princess</h4>
                            <div class="game-hover-content">
                                <h5>Rome</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.34s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-junglespirit.jpeg" alt="" />
                            </div>
                            <h4>Jungle Spirit</h4>
                            <div class="game-hover-content">
                                <h5>Rome</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.35s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-jackbeanstalk.jpeg" alt="" />
                            </div>
                            <h4>Jack and the Beanstalk</h4>
                            <div class="game-hover-content">
                                <h5>Rome</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.36s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-hotline.jpeg" alt="" />
                            </div>
                            <h4>Hotline</h4>
                            <div class="game-hover-content">
                                <h5>Rome</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.37s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-gorillakingdom.jpeg" alt="" />
                            </div>
                            <h4>Gorilla Kingdom</h4>
                            <div class="game-hover-content">
                                <h5>Rome</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.38s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-fruitshop.jpeg" alt="" />
                            </div>
                            <h4>Fruit Shop</h4>
                            <div class="game-hover-content">
                                <h5>Rome</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.39s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-butterfly.jpeg" alt="" />
                            </div>
                            <h4>Butterfly</h4>
                            <div class="game-hover-content">
                                <h5>Rome</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.4s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game-asgardianstones.jpeg" alt="" />
                            </div>
                            <h4>Asgardian Stones</h4>
                            <div class="game-hover-content">
                                <h5>Rome</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                    <li class="game-item os-animation" data-os-animation="fadeInUp" data-os-animation-delay="0.41s">
                        <a href="#!" class="game-box">
                            <div class="game-img-box">
                                <img src="include/images/game_starburst.jpeg" alt="" />
                            </div>
                            <h4>Starburst</h4>
                            <div class="game-hover-content">
                                <h5>Rome</h5>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!--============================== Content End ==============================-->


<?php get_footer(); ?>