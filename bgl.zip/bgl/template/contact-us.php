<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: Contact Us */
get_header();
?>	


<?php get_footer(); ?>