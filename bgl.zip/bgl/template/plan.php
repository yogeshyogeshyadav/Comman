<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: Plan */
get_header();
?>	


<?php get_footer(); ?>