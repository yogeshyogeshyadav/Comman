<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: Manchester Golf Club */
get_header();
?>	


<?php get_footer(); ?>