<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: Golf Course */
get_header();
?>	


<?php get_footer(); ?>