<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: Homepage */
get_header();
?>	


<?php get_footer(); ?>