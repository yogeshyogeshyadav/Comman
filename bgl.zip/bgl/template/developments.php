<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: Developments */
get_header();
?>	


<?php get_footer(); ?>