<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: Leisure Space */
get_header();
?>	


<?php get_footer(); ?>