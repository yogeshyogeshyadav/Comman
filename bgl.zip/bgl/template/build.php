<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: Build */
get_header();
?>	


<?php get_footer(); ?>