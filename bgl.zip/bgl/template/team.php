<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: Our Team */
get_header();
?>	


<?php get_footer(); ?>