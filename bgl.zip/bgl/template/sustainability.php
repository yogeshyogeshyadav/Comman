<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: Sustainability */
get_header();
?>	


<?php get_footer(); ?>