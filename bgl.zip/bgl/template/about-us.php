<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
/* Template Name: About US */
get_header();
?>	


<?php get_footer(); ?>