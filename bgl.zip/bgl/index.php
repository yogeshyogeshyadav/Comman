<?php
/*==============================*/
// @package Booth-Golf
// @author SLICEmyPAGE
/*==============================*/
get_header(); ?>

<?php get_footer(); ?>