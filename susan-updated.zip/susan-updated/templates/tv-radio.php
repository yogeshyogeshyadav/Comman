<?php
/*==============================*/
// @package SusanCalman
// @author Thinkeq
/*==============================*/
/* Template Name: TV Radio */
get_header(); 

$tv_heading = get_field('tv_heading');
$tv_body_text = get_field('tv_body_text');
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="main-inner">
                <?php get_template_part('template-part/inner-banner'); ?>
                <!--============================== Content Start ==============================-->
                <?php if(have_rows('playlist')): ?>
                <!--============================== Content Start ==============================-->
                <div class="content-container pt-0">
                    <div class="row">
                        <div class="col-lg-10 offset-lg-1">
                            <div class="tv-container">
                                <svg class="svg" id="Group_182" data-name="Group 182" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="415.64" height="271.039" viewBox="0 0 415.64 271.039">
                                    <clipPath id="my-clip-path">
                                        <path id="Path_409" data-name="Path 409" d="M1255.678,515.327a1467.954,1467.954,0,0,1-330.247,0,44.083,44.083,0,0,1-38.876-44V311.9a44.084,44.084,0,0,1,38.876-44,1467.935,1467.935,0,0,1,330.247,0,44.084,44.084,0,0,1,38.877,44V471.329A44.084,44.084,0,0,1,1255.678,515.327Z" transform="translate(-886.554 -258.586)" fill="none"/>
                                    </clipPath>
                                </svg>
                                <div class="tv-video-frame">
                                    <img src="<?php echo IMG.'tv-blank.svg'; ?>" alt="TV Frame" />
                                    <span class="tv-shape-mob d-block d-md-none"></span>
                                    <div class="tv-video-slider">
                                        <?php while(have_rows('playlist')): the_row(); ?>
                                        <div class="tv-video-slide">
                                            <div class="embed-responsive embed-responsive-4by3">
                                                <?php
                                                    $video = get_sub_field('video');
                                                    echo ao_iframe($video);
                                                ?>
                                            </div>
                                        </div>
                                        <?php endwhile; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="tv-thumb-container">
                                <div class="tv-thumbnail-slider">
                                    <?php while(have_rows('playlist')): the_row(); ?>
                                    <div class="tv-thumbnail-slide">
                                        <div class="tv-thumbnail-box">
                                            <div class="tv-thumbnail-img">
                                                <?php
                                                $video_url = get_sub_field('video', FALSE, FALSE);
                                                $thumb = get_video_thumbnail_uri($video_url);
                                                echo '<img src="'.$thumb.'" alt="Video Thumbnail" />';
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endwhile; ?>
                                </div>
                                <div class="tv-content-slider">
                                    <?php while(have_rows('playlist')): the_row(); ?>
                                    <div class="tv-content-slide">
                                        <div class="tv-content-box">
                                            <div class="tv-content-content">
                                                <?php
                                                $heading = get_sub_field('heading');
                                                $body_text = get_sub_field('body_text');
                                                if(!empty($heading)): echo '<h6>'.$heading.'</h6>'; endif;
                                                if(!empty($body_text)): echo '<p>'.$body_text.'</p>'; endif;
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endwhile; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--============================== Content End ==============================-->
                <?php endif; ?>
                <!--============================== Content End ==============================-->
                <?php if(!empty($tv_body_text)): ?>
                <!--============================== Content Start ==============================-->
                <div class="content-container pt-0">
                    <div class="row">
                        <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2">
                            <div class="main-content">
                                <?php 
                                if(!empty($tv_heading)): echo '<h4>'.$tv_heading.'</h4>'; endif; 
                                echo $tv_body_text;
                                if(have_rows('icon_list')):
                                ?>
                                <div class="icon">
                                <?php 
                                while(have_rows('icon_list')): the_row();
                                $logo = wp_get_attachment_image(get_sub_field('logo'),'thumbnail');
                                $url = get_sub_field('url');
                                echo '<a href="'.$url.'" target="_blank">'.$logo.'</a>';
                                endwhile;
                                ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!--============================== Content End ==============================-->
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>